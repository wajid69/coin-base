

const Footer = () => {
  return (
    <div className="footer-container">
      <p>All Right Reserved @BitCoin 2024</p>
    </div>
  )
}

export default Footer
